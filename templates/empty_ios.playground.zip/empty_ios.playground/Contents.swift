import Foundation

var str = "Hello, playground"
